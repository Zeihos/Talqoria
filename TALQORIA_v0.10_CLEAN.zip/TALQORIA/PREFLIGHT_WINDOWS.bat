@echo off
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
    echo ERROR: Node.js 20+ is required.
    pause
    exit /b 3
)
node "tools\preflight.js" "%~dp0"
set "CODE=%ERRORLEVEL%"
echo.
echo Preflight exit code: %CODE%
pause
exit /b %CODE%
