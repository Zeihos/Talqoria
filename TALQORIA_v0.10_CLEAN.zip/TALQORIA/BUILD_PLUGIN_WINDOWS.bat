@echo off
cd /d "%~dp0"
where java >nul 2>&1
if errorlevel 1 (
    echo ERROR: JDK 21 is required. Java was not found.
    pause
    exit /b 1
)
where mvn >nul 2>&1
if errorlevel 1 (
    echo ERROR: Maven 3.9+ is required and must be in PATH.
    pause
    exit /b 1
)
call mvn -f "plugin\pom.xml" clean package
if errorlevel 1 (
    echo Maven build failed; see errors above. Do not deploy.
    pause
    exit /b 1
)
if not exist "server\plugins" mkdir "server\plugins"
copy /Y "plugin\target\talqoria-core-0.10.0.jar" "server\plugins\TalqoriaCore.jar"
if errorlevel 1 (
    echo ERROR: Built, but failed to copy JAR into server\plugins.
    pause
    exit /b 1
)
echo ===========================================
echo TalqoriaCore.jar copied to server\plugins
echo Next: put compatible paper.jar in server\ and run start-windows.bat.
echo ===========================================
pause
