@echo off
cd /d "%~dp0"
if not exist "paper.jar" (
    echo ERROR: paper.jar not found in this folder.
    echo Download a compatible Paper build from https://papermc.io/downloads/paper
    pause
    exit /b 1
)
java -Xms2G -Xmx4G -jar paper.jar --nogui
pause
