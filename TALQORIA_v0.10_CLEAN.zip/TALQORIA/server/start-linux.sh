#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if [ ! -f paper.jar ]; then
  echo 'ERROR: paper.jar not found. Download a compatible Paper build from https://papermc.io/downloads/paper' >&2
  exit 1
fi
exec java -Xms2G -Xmx4G -jar paper.jar --nogui
