@echo off
setlocal
cd /d "%~dp0"
echo ===========================================
echo TALQORIA v0.11 - BUILD ENVIRONMENT CHECK
echo ===========================================
where javac >nul 2>&1
if errorlevel 1 (echo [FAIL] JDK not found. Install JDK 21. & goto :fail)
java -version 2>&1
where mvn >nul 2>&1
if errorlevel 1 (echo [FAIL] Maven not found. Install Maven 3.9+ and add bin to PATH.& goto :fail)
call mvn -version
if errorlevel 1 (echo [FAIL] Maven broken.& goto :fail)
where node >nul 2>&1
if errorlevel 1 (echo [FAIL] Node.js not found. Install Node.js 20+.& goto :fail)
node --version
if not exist "server\paper.jar" (echo [NOTICE] Put a compatible Paper 1.21.11 server jar in server\paper.jar.)
if not exist "server\plugins\TalqoriaCore.jar" (echo [NOTICE] Plugin is not built yet. Run BUILD_PLUGIN_WINDOWS.bat.)
echo [OK] All executables found. Actual versions, network and Paper runtime require validation.
pause
exit /b 0
:fail
pause
exit /b 1
